
Make sure you have your own credentials:
 - in backend/.env file for MONGO_URI variable
 - frontend/src/pages/user/UserOrderDetailsPage.js for PayPal client-id

1. Open terminal on the frontend folder and run "npm install"
2. Open terminal on the backend folder and run "npm install"
3. Having terminal opened on the backend run "npm run dev" to run the application
4. Optionally run seeders by running "npm run seed:data" (being in the backend folder)
