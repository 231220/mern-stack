const recordsPerPage = 3
module.exports = recordsPerPage